package org.vivecraft.client_vr.provider.nexavr;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexSorting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.vivecraft.client_vr.provider.MCVR;
import org.vivecraft.client_vr.settings.VRSettings;

/**
 * Nexa-only phone/VRBox pre-distortion.
 *
 * Uses a subdivided textured mesh instead of a custom GLSL program. That keeps the
 * output on Minecraft's existing POSITION_TEX shader path, which is friendlier to
 * Android/Pojav GL translation layers. If anything fails, the caller falls back to
 * Vivecraft's normal raw DUAL blit.
 */
public final class NexaLensDistortion {
    private static boolean warned;

    private NexaLensDistortion() {}

    public static boolean isEnabledFor(MCVR vr) {
        return vr instanceof NexaVR && boolProp("nexa.lensWarp", true);
    }

    public static boolean blitDual(RenderTarget left, RenderTarget right, int screenWidth, int screenHeight) {
        if (left == null || right == null || screenWidth < 4 || screenHeight < 4) return false;
        PoseStack modelView = null;
        boolean modelViewPushed = false;
        try {
            int grid = intProp("nexa.lensGrid", 32, 8, 64);
            float k1 = floatProp("nexa.lensK1", 0.12F, -1.0F, 1.0F);
            float k2 = floatProp("nexa.lensK2", 0.04F, -1.0F, 1.0F);
            float scale = floatProp("nexa.lensScale", 1.12F, 0.70F, 1.40F);
            float centerX = floatProp("nexa.lensCenterX", 0.0F, -0.35F, 0.35F);
            float centerY = floatProp("nexa.lensCenterY", 0.0F, -0.35F, 0.35F);
            boolean flipV = boolProp("nexa.lensFlipV", true);

            RenderSystem.viewport(0, 0, screenWidth, screenHeight);
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.disableBlend();
            RenderSystem.disableCull();
            RenderSystem.clearColor(0.0F, 0.0F, 0.0F, 1.0F);
            RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT, Minecraft.ON_OSX);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.setProjectionMatrix(
                new Matrix4f().setOrtho(0.0F, (float) screenWidth, (float) screenHeight, 0.0F, -1000.0F, 1000.0F),
                VertexSorting.ORTHOGRAPHIC_Z);

            modelView = RenderSystem.getModelViewStack();
            modelView.pushPose();
            modelViewPushed = true;
            modelView.setIdentity();
            RenderSystem.applyModelViewMatrix();
            RenderSystem.setShader(GameRenderer::getPositionTexShader);

            int half = screenWidth / 2;
            drawEye(left, 0, half, screenHeight, grid, k1, k2, scale, centerX, centerY, flipV);
            drawEye(right, half, screenWidth - half, screenHeight, grid, k1, k2, scale, centerX, centerY, flipV);

            modelView.popPose();
            modelViewPushed = false;
            RenderSystem.applyModelViewMatrix();
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            return true;
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                VRSettings.logger.error("Nexa lens warp failed; falling back to raw Vivecraft DUAL mirror", t);
            }
            try {
                if (modelViewPushed && modelView != null) {
                    modelView.popPose();
                    RenderSystem.applyModelViewMatrix();
                }
                RenderSystem.depthMask(true);
                RenderSystem.enableDepthTest();
                RenderSystem.enableCull();
            } catch (Throwable ignored) {}
            return false;
        }
    }

    private static void drawEye(RenderTarget target, int xOffset, int width, int height, int grid,
                                float k1, float k2, float scale, float centerX, float centerY,
                                boolean flipV) {
        RenderSystem.setShaderTexture(0, target.getColorTextureId());
        Tesselator tess = RenderSystem.renderThreadTesselator();
        BufferBuilder b = tess.getBuilder();
        b.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);

        for (int gy = 0; gy < grid; gy++) {
            float v0 = gy / (float) grid;
            float v1 = (gy + 1) / (float) grid;
            float ny0 = v0 * 2.0F - 1.0F;
            float ny1 = v1 * 2.0F - 1.0F;
            for (int gx = 0; gx < grid; gx++) {
                float u0 = gx / (float) grid;
                float u1 = (gx + 1) / (float) grid;
                float nx0 = u0 * 2.0F - 1.0F;
                float nx1 = u1 * 2.0F - 1.0F;

                float[] p00 = NexaLensMath.warp(nx0, ny0, centerX, centerY, k1, k2, scale);
                float[] p10 = NexaLensMath.warp(nx1, ny0, centerX, centerY, k1, k2, scale);
                float[] p11 = NexaLensMath.warp(nx1, ny1, centerX, centerY, k1, k2, scale);
                float[] p01 = NexaLensMath.warp(nx0, ny1, centerX, centerY, k1, k2, scale);

                float sv0 = flipV ? 1.0F - v0 : v0;
                float sv1 = flipV ? 1.0F - v1 : v1;
                vertex(b, p00, xOffset, width, height, u0, sv0);
                vertex(b, p10, xOffset, width, height, u1, sv0);
                vertex(b, p11, xOffset, width, height, u1, sv1);
                vertex(b, p01, xOffset, width, height, u0, sv1);
            }
        }
        BufferUploader.drawWithShader(b.end());
    }

    private static void vertex(BufferBuilder b, float[] p, int xOffset, int width, int height, float u, float v) {
        float x = xOffset + (p[0] * 0.5F + 0.5F) * width;
        float y = (p[1] * 0.5F + 0.5F) * height;
        b.vertex(x, y, 0.0F).uv(u, v).endVertex();
    }

    private static boolean boolProp(String name, boolean fallback) {
        String s = System.getProperty(name);
        return s == null ? fallback : Boolean.parseBoolean(s);
    }

    private static int intProp(String name, int fallback, int min, int max) {
        try { return Math.max(min, Math.min(max, Integer.parseInt(System.getProperty(name, Integer.toString(fallback))))); }
        catch (Throwable ignored) { return fallback; }
    }

    private static float floatProp(String name, float fallback, float min, float max) {
        try {
            float v = Float.parseFloat(System.getProperty(name, Float.toString(fallback)));
            if (!Float.isFinite(v)) return fallback;
            return Math.max(min, Math.min(max, v));
        } catch (Throwable ignored) { return fallback; }
    }
}
