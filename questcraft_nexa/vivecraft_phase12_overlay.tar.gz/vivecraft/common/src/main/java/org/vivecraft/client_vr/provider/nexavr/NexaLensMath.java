package org.vivecraft.client_vr.provider.nexavr;

/** Pure lens-warp math kept independent from Minecraft/OpenGL so it can be unit-tested. */
public final class NexaLensMath {
    private NexaLensMath() {}

    public static float[] warp(float x, float y, float centerX, float centerY,
                               float k1, float k2, float scale) {
        if (!Float.isFinite(x) || !Float.isFinite(y)) return new float[]{0.0F, 0.0F};
        centerX = finiteOr(centerX, 0.0F);
        centerY = finiteOr(centerY, 0.0F);
        k1 = clamp(finiteOr(k1, 0.12F), -1.0F, 1.0F);
        k2 = clamp(finiteOr(k2, 0.04F), -1.0F, 1.0F);
        scale = clamp(finiteOr(scale, 1.12F), 0.70F, 1.40F);

        float dx = x - centerX;
        float dy = y - centerY;
        float r2 = dx * dx + dy * dy;
        float radial = 1.0F + k1 * r2 + k2 * r2 * r2;
        radial = clamp(radial, 0.20F, 4.0F);

        return new float[]{
            centerX + dx * scale / radial,
            centerY + dy * scale / radial
        };
    }

    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float finiteOr(float value, float fallback) {
        return Float.isFinite(value) ? value : fallback;
    }
}
