package org.vivecraft.client_vr.provider.nexavr;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Tuple;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.vivecraft.client_vr.ClientDataHolderVR;
import org.vivecraft.client_vr.VRTextureTarget;
import org.vivecraft.client_vr.provider.MCVR;
import org.vivecraft.client_vr.provider.VRRenderer;
import org.vivecraft.client_vr.render.RenderConfigException;
import org.vivecraft.client_vr.render.RenderPass;

/** Phone stereo renderer: two eye textures. Vivecraft MirrorMode.DUAL composites them side-by-side to the phone window for VRBox. */
public final class NexaVRStereoRenderer extends VRRenderer {
    private int left=-1,right=-1; private RenderTarget eye0,eye1;
    NexaVRStereoRenderer(MCVR vr){super(vr);}
    @Override public Tuple<Integer,Integer> getRenderTextureSizes(){
        if(resolution==null){int w=Integer.getInteger("nexa.eyeWidth",1280),h=Integer.getInteger("nexa.eyeHeight",1440);resolution=new Tuple<>(w,h);ss=-1f;}return resolution;
    }
    @Override public Matrix4f getProjectionMatrix(int eye,float near,float far){
        float fov=75f;
        try { fov=Float.parseFloat(System.getProperty("nexa.fov","75")); } catch(Throwable ignored) {}
        if(!Float.isFinite(fov)) fov=75f;
        fov=Math.max(45f,Math.min(120f,fov));
        Tuple<Integer,Integer> size=getRenderTextureSizes();
        float aspect=Math.max(0.25f,(float)size.getA()/Math.max(1,size.getB()));
        return new Matrix4f().setPerspective((float)Math.toRadians(fov),aspect,near,far);
    }
    @Override public void createRenderTexture(int w,int h) throws RenderConfigException{
        left=createTex(w,h);right=createTex(w,h); ClientDataHolderVR d=ClientDataHolderVR.getInstance();
        if(left<0||right<0)throw new RenderConfigException("Nexa stereo init", Component.literal("eye texture allocation failed"));
        eye0=new VRTextureTarget("Nexa L Eye",w,h,false,false,left,false,true,false);
        eye1=new VRTextureTarget("Nexa R Eye",w,h,false,false,right,false,true,false);
        d.print(eye0.toString());d.print(eye1.toString());
    }
    private int createTex(int w,int h){int id=GlStateManager._genTexture(),old=GlStateManager._getInteger(GL11.GL_TEXTURE_BINDING_2D);RenderSystem.bindTexture(id);RenderSystem.texParameter(GL11.GL_TEXTURE_2D,GL11.GL_TEXTURE_MIN_FILTER,GL11.GL_LINEAR);RenderSystem.texParameter(GL11.GL_TEXTURE_2D,GL11.GL_TEXTURE_MAG_FILTER,GL11.GL_LINEAR);GlStateManager._texImage2D(GL11.GL_TEXTURE_2D,0,GL11.GL_RGBA8,w,h,0,GL11.GL_RGBA,GL11.GL_UNSIGNED_BYTE,null);RenderSystem.bindTexture(old);return id;}
    @Override public void endFrame() { /* No headset submit: Vivecraft's DUAL mirror presents both eye targets to the Android window. */ }
    @Override public boolean providesStencilMask(){return false;}
    @Override public RenderTarget getLeftEyeTarget(){return eye0;}
    @Override public RenderTarget getRightEyeTarget(){return eye1;}
    @Override public float[] getStencilMask(RenderPass eye){return null;}
    @Override public String getName(){return "NexaStereo";}
    @Override public String getLastError(){return "";}
    @Override public boolean isInitialized(){return vr.initSuccess;}
    @Override public String getinitError(){return vr.initStatus;}
    @Override public void destroy(){super.destroy();if(eye0!=null)eye0.destroyBuffers();if(eye1!=null)eye1.destroyBuffers();eye0=eye1=null;if(left>-1)TextureUtil.releaseTextureId(left);if(right>-1)TextureUtil.releaseTextureId(right);left=right=-1;}
}
