package org.vivecraft.client_vr.provider.nexavr;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Arrays;

/** Receives the latest Nexa pose/input packet from Android ART over localhost. */
public final class NexaBridgeClient implements AutoCloseable {
    public static final int PORT=47821, MAGIC=0x4E585231;
    public final float[] head={0,1.62f,0,0,0,0,1};
    public final float[] joints=new float[126];
    public final float[] pinch=new float[8];
    public volatile int validHands, buttons;
    public volatile boolean headTracked;
    public volatile float leftX,leftY,rightX,rightY,leftTrigger,rightTrigger;
    public volatile long lastPacketNanos;
    private long lastSenderNanos;
    private volatile boolean alive=true;
    private final DatagramSocket socket;
    private final Thread thread;

    public NexaBridgeClient() throws Exception {
        Arrays.fill(pinch,1f);
        socket=new DatagramSocket(PORT, InetAddress.getByName("127.0.0.1"));
        socket.setReceiveBufferSize(64*1024);
        thread=new Thread(this::loop,"NexaXR-UDP");
        thread.setDaemon(true); thread.start();
    }
    private void loop(){
        byte[] buf=new byte[1024];
        while(alive){
            try{
                DatagramPacket p=new DatagramPacket(buf,buf.length); socket.receive(p);
                DataInputStream in=new DataInputStream(new ByteArrayInputStream(p.getData(),0,p.getLength()));
                if(in.readInt()!=MAGIC || in.readInt()!=1) continue;
                long senderNanos=in.readLong();
                in.readLong(); // Android tracking timestamp (uptime ms), reserved for diagnostics.
                boolean tracked=in.readBoolean(); int mask=in.readUnsignedByte();
                float[] h=new float[7], j=new float[126], pn=new float[8];
                for(int i=0;i<7;i++)h[i]=in.readFloat();
                for(int i=0;i<126;i++)j[i]=in.readFloat();
                for(int i=0;i<8;i++)pn[i]=in.readFloat();
                float lx=in.readFloat(),ly=in.readFloat(),rx=in.readFloat(),ry=in.readFloat();
                float lt=in.readFloat(),rt=in.readFloat(); int b=in.readInt();
                synchronized(this){
                    // Loopback UDP should preserve order in practice, but reject an older sample
                    // so a delayed datagram can never rewind the user's head/hands.
                    if(senderNanos <= lastSenderNanos) continue;
                    lastSenderNanos=senderNanos;
                    System.arraycopy(h,0,head,0,7); System.arraycopy(j,0,joints,0,126); System.arraycopy(pn,0,pinch,0,8);
                    headTracked=tracked; validHands=mask; leftX=lx;leftY=ly;rightX=rx;rightY=ry;leftTrigger=lt;rightTrigger=rt;buttons=b;
                    lastPacketNanos=System.nanoTime();
                }
            }catch(Throwable e){ if(alive) try{Thread.sleep(2);}catch(InterruptedException ignored){} }
        }
    }
    public boolean fresh(){ return System.nanoTime()-lastPacketNanos < 300_000_000L; }
    public boolean handValid(int id){return (validHands&(1<<id))!=0;}
    public void joint(int hand,int joint,float[] dst){int k=hand*63+joint*3;dst[0]=joints[k];dst[1]=joints[k+1];dst[2]=joints[k+2];}
    @Override public void close(){alive=false;socket.close();try{thread.join(100);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
}
