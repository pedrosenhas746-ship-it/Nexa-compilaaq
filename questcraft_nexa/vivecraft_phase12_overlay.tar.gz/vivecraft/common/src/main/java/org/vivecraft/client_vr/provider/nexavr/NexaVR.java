package org.vivecraft.client_vr.provider.nexavr;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.joml.Quaternionf;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.vivecraft.client.VivecraftVRMod;
import org.vivecraft.client.utils.Utils;
import org.vivecraft.client_vr.ClientDataHolderVR;
import org.vivecraft.client_vr.provider.ControllerType;
import org.vivecraft.client_vr.provider.MCVR;
import org.vivecraft.client_vr.provider.VRRenderer;
import org.vivecraft.client_vr.provider.control.VRInputAction;
import org.vivecraft.client_vr.settings.VRSettings;
import org.vivecraft.common.utils.math.Matrix4f;

import java.util.List;

/**
 * QuestCraft/Vivecraft provider backed by Nexa ARCore + MediaPipe tracking.
 *
 * Vivecraft controller indices follow ControllerType exactly:
 *   0 = RIGHT, 1 = LEFT.
 * Android's normal Pojlib/QCXR gamepad remapper remains the button/stick path;
 * this provider supplies spatial head/hand poses and must not consume or release
 * those Android-generated Minecraft key/mouse events.
 */
public final class NexaVR extends MCVR {
    private static final int RIGHT = 0;
    private static final int LEFT = 1;

    private NexaBridgeClient bridge;
    private final float ipd;
    private boolean originSet;
    private float originX, originY, originZ;

    // Four stable palm landmarks per hand: wrist, index MCP, pinky MCP, middle MCP.
    // Lightweight adaptive smoothing removes MediaPipe shimmer without making fast swings sluggish.
    private final float[][] filteredPalm = new float[2][12];
    private final boolean[] filteredPalmValid = new boolean[2];

    public NexaVR(Minecraft mc, ClientDataHolderVR dh) {
        super(mc, dh, VivecraftVRMod.INSTANCE);
        this.hapticScheduler = new NexaVRHapticScheduler();
        this.ipd = propertyFloat("nexa.ipd", 0.064f, 0.050f, 0.080f);
    }

    @Override
    public boolean init() {
        if (initialized) return true;
        try {
            bridge = new NexaBridgeClient();
            mc = Minecraft.getInstance();

            dh.vrSettings.seated = false;

            // VRBox: present both rendered eyes on the phone at the same time.
            // Vivecraft's existing DUAL mirror does the SBS composition.
            dh.vrSettings.displayMirrorMode = VRSettings.MirrorMode.DUAL;
            dh.vrSettings.displayMirrorUseScreenshotCamera = false;

            // Spatial hands remain active while QCXR/Pojlib handles the physical controller.
            dh.vrSettings.weaponCollision = VRSettings.WeaponCollision.ON;
            dh.vrSettings.realisticBlockInteractEnabled = true;
            dh.vrSettings.realisticEntityInteractEnabled = true;

            Utils.Matrix4fSetIdentity(hmdPose);
            Utils.Matrix4fSetIdentity(hmdRotation);
            Utils.Matrix4fSetIdentity(hmdPoseLeftEye);
            Utils.Matrix4fSetIdentity(hmdPoseRightEye);
            hmdPoseLeftEye.M[0][3] = -ipd * 0.5f;
            hmdPoseRightEye.M[0][3] = ipd * 0.5f;

            initialized = true;
            initSuccess = true;
            initStatus = "Nexa bridge ready";
            headIsTracking = false;
            return true;
        } catch (Throwable t) {
            initSuccess = false;
            initStatus = "Nexa bridge: " + t.getClass().getSimpleName() + ": " + t.getMessage();
            return false;
        }
    }

    @Override
    public void poll(long frameIndex) {
        if (!initialized || bridge == null) return;

        // Fail closed on a dead/stalled Android tracker. Phase 1.1 left stale hands marked tracked.
        if (!bridge.fresh()) {
            headIsTracking = false;
            controllerTracking[RIGHT] = false;
            controllerTracking[LEFT] = false;
            filteredPalmValid[RIGHT] = false;
            filteredPalmValid[LEFT] = false;
            return;
        }

        synchronized (bridge) {
            if (bridge.headTracked) {
                if (!originSet) {
                    // First reliable ARCore pose becomes standing eye height.
                    originX = bridge.head[0];
                    originY = bridge.head[1] - 1.62f;
                    originZ = bridge.head[2];
                    originSet = true;
                }

                float[] head = bridge.head.clone();
                if (originSet) {
                    head[0] -= originX;
                    head[1] -= originY;
                    head[2] -= originZ;
                }
                setPose(hmdPose, hmdRotation, head);
                headIsTracking = true;
            } else {
                headIsTracking = false;
            }

            controllerTracking[RIGHT] = bridge.handValid(RIGHT) && updateHand(RIGHT);
            controllerTracking[LEFT] = bridge.handValid(LEFT) && updateHand(LEFT);
            if (!controllerTracking[RIGHT]) filteredPalmValid[RIGHT] = false;
            if (!controllerTracking[LEFT]) filteredPalmValid[LEFT] = false;
        }

        // MCVR derives aim source, hand rotation and histories from controllerPose.
        updateAim();
        hmdSampling();
    }

    /** Build an OpenXR-like controller pose where local -Z points from wrist toward the fingers. */
    private boolean updateHand(int hand) {
        if (!bridge.handValid(hand)) return false;

        float[] wrist = new float[3];
        float[] index = new float[3];
        float[] pinky = new float[3];
        float[] middle = new float[3];
        bridge.joint(hand, 0, wrist);
        bridge.joint(hand, 5, index);
        bridge.joint(hand, 17, pinky);
        bridge.joint(hand, 9, middle);

        if (originSet) {
            offsetOrigin(wrist);
            offsetOrigin(index);
            offsetOrigin(pinky);
            offsetOrigin(middle);
        }
        if (!finite3(wrist) || !finite3(index) || !finite3(pinky) || !finite3(middle)) return false;

        float[] raw = new float[]{
                wrist[0], wrist[1], wrist[2],
                index[0], index[1], index[2],
                pinky[0], pinky[1], pinky[2],
                middle[0], middle[1], middle[2]
        };
        float[] p = smoothPalm(hand, raw);

        Vector3f w = v3(p, 0);
        Vector3f i = v3(p, 3);
        Vector3f pk = v3(p, 6);
        Vector3f m = v3(p, 9);

        Vector3f forward = new Vector3f(m).sub(w);
        if (forward.lengthSquared() < 1.0e-6f) return false;
        forward.normalize();

        // Normalize both hands to the same controller coordinate convention.
        // OpenXR/Vivecraft local +X points right; local -Z points forward.
        Vector3f x = hand == RIGHT ? new Vector3f(pk).sub(i) : new Vector3f(i).sub(pk);
        x.sub(new Vector3f(forward).mul(x.dot(forward)));
        if (x.lengthSquared() < 1.0e-6f) return false;
        x.normalize();

        Vector3f z = new Vector3f(forward).negate(); // therefore local -Z == physical finger direction
        Vector3f y = new Vector3f(z).cross(x);
        if (y.lengthSquared() < 1.0e-6f) return false;
        y.normalize();
        x.set(new Vector3f(y).cross(z).normalize());

        // Grip anchor = palm center rather than the wrist, closer to a Quest controller grip pose.
        Vector3f pos = new Vector3f(w).add(i).add(pk).add(m).mul(0.25f);

        Matrix4f pose = controllerPose[hand];
        Utils.Matrix4fSetIdentity(pose);
        pose.M[0][0] = x.x; pose.M[1][0] = x.y; pose.M[2][0] = x.z;
        pose.M[0][1] = y.x; pose.M[1][1] = y.y; pose.M[2][1] = y.z;
        pose.M[0][2] = z.x; pose.M[1][2] = z.y; pose.M[2][2] = z.z;
        pose.M[0][3] = pos.x; pose.M[1][3] = pos.y; pose.M[2][3] = pos.z;
        return true;
    }

    private float[] smoothPalm(int hand, float[] raw) {
        float[] filtered = filteredPalm[hand];
        if (!filteredPalmValid[hand]) {
            System.arraycopy(raw, 0, filtered, 0, raw.length);
            filteredPalmValid[hand] = true;
            return filtered;
        }

        float dx = raw[0] - filtered[0];
        float dy = raw[1] - filtered[1];
        float dz = raw[2] - filtered[2];
        float distance = (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
        final float alpha = distance > 0.10f ? 0.86f : distance > 0.04f ? 0.62f : 0.38f;
        for (int n = 0; n < raw.length; n++) {
            filtered[n] += (raw[n] - filtered[n]) * alpha;
        }
        return filtered;
    }

    private void offsetOrigin(float[] p) {
        p[0] -= originX;
        p[1] -= originY;
        p[2] -= originZ;
    }

    private static Vector3f v3(float[] a, int i) {
        return new Vector3f(a[i], a[i + 1], a[i + 2]);
    }

    private static boolean finite3(float[] v) {
        return Float.isFinite(v[0]) && Float.isFinite(v[1]) && Float.isFinite(v[2]);
    }

    private static void setPose(Matrix4f pose, Matrix4f rotation, float[] v) {
        if (v == null || v.length < 7) return;
        Quaternionf q = new Quaternionf(v[3], v[4], v[5], v[6]);
        if (!Float.isFinite(q.x) || !Float.isFinite(q.y) || !Float.isFinite(q.z) || !Float.isFinite(q.w)) return;
        q.normalize();
        org.joml.Matrix3f m = new org.joml.Matrix3f().rotation(q);
        Utils.Matrix4fSetIdentity(pose);
        Utils.Matrix4fSetIdentity(rotation);
        pose.M[0][0] = rotation.M[0][0] = m.m00();
        pose.M[0][1] = rotation.M[0][1] = m.m10();
        pose.M[0][2] = rotation.M[0][2] = m.m20();
        pose.M[1][0] = rotation.M[1][0] = m.m01();
        pose.M[1][1] = rotation.M[1][1] = m.m11();
        pose.M[1][2] = rotation.M[1][2] = m.m21();
        pose.M[2][0] = rotation.M[2][0] = m.m02();
        pose.M[2][1] = rotation.M[2][1] = m.m12();
        pose.M[2][2] = rotation.M[2][2] = m.m22();
        pose.M[0][3] = v[0];
        pose.M[1][3] = v[1];
        pose.M[2][3] = v[2];
    }

    private static float propertyFloat(String name, float fallback, float min, float max) {
        try {
            float v = Float.parseFloat(System.getProperty(name, Float.toString(fallback)));
            if (!Float.isFinite(v)) return fallback;
            return Math.max(min, Math.min(max, v));
        } catch (Throwable ignored) {
            return fallback;
        }
    }

    @Override
    public void processInputs() {
        // Intentionally empty. QCXR/Pojlib already converts the physical Android gamepad into
        // Minecraft keyboard/mouse events. Calling MCVR.processInputs() here would process empty
        // VRInputActions and can release those same keys, causing stuck/flickering controls.
    }

    @Override
    public void destroy() {
        initialized = false;
        initSuccess = false;
        headIsTracking = false;
        controllerTracking[RIGHT] = false;
        controllerTracking[LEFT] = false;
        if (bridge != null) bridge.close();
        bridge = null;
    }

    @Override public String getID() { return "nexa"; }
    @Override public String getName() { return "Nexa XR"; }
    @Override public String getRuntimeName() { return "Nexa"; }
    @Override public Vector2f getPlayAreaSize() { return new Vector2f(3f, 3f); }
    @Override public boolean postinit() { populateInputActions(); return true; }
    @Override public VRRenderer createVRRenderer() { return new NexaVRStereoRenderer(this); }
    @Override public boolean isActive() { return true; }
    @Override public boolean capFPS() { return true; }
    @Override public float getIPD() { return ipd; }
    @Override public boolean hasThirdController() { return false; }
    @Override public List<Long> getOrigins(VRInputAction a) { return null; }
    @Override public ControllerType getOriginControllerType(long i) { return i == 0 ? ControllerType.RIGHT : ControllerType.LEFT; }
    @Override protected ControllerType findActiveBindingControllerType(KeyMapping b) { return null; }
    @Override @Deprecated protected void triggerBindingHapticPulse(KeyMapping b, int duration) { }
    @Override public Matrix4f getControllerComponentTransform(int controllerIndex, String componentName) { return new Matrix4f(); }
    @Override public String getOriginName(long h) { return h == 0 ? "Nexa Right" : "Nexa Left"; }
}
